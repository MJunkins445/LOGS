import { useState, useEffect } from 'react';
import { apiFetch } from '../useBackend';
import { Spinner } from '../components/LoadingBar';
import './Firewall.css';

function Firewall({ backendReady, firewallResults, setFirewallResults }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newRule, setNewRule] = useState({
    name: '', port: '', protocol: 'tcp', action: 'Block', direction: 'Inbound', source_ip: '', description: '',
  });

  // Only auto-load once the backend is ready
  useEffect(() => {
    if (backendReady && !firewallResults) {
      loadFirewallData();
    }
  }, [backendReady]);

  async function loadFirewallData() {
    setLoading(true);
    setError('');
    try {
      const data = await apiFetch('/api/firewall/analyze');
      setFirewallResults(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleAddRule(e) {
    e.preventDefault();
    setError('');
    try {
      const result = await apiFetch('/api/firewall/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRule),
      });
      if (result.success) {
        setShowAddModal(false);
        setNewRule({ name: '', port: '', protocol: 'tcp', action: 'Block', direction: 'Inbound', source_ip: '', description: '' });
        loadFirewallData();
      } else {
        setError('Failed to create rule');
      }
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleToggleRule(ruleName, enable) {
    try {
      const action = enable ? 'enable' : 'disable';
      const result = await apiFetch(`/api/firewall/${action}/${encodeURIComponent(ruleName)}`, { method: 'POST' });
      if (result.success) loadFirewallData();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleRemoveRule(ruleName) {
    if (!confirm(`Are you sure you want to remove the rule "${ruleName}"?`)) return;
    try {
      const result = await apiFetch(`/api/firewall/remove/${encodeURIComponent(ruleName)}`, { method: 'DELETE' });
      if (result.success) loadFirewallData();
    } catch (err) {
      setError(err.message);
    }
  }

  const rules = firewallResults?.rules || [];
  const issues = firewallResults?.issues || [];

  const filteredRules = rules.filter(rule => {
    if (filter === 'all') return true;
    if (filter === 'issues') return issues.some(i => i.rule_name === rule.DisplayName);
    if (filter === 'enabled') return String(rule.Enabled).toLowerCase() === 'true';
    if (filter === 'disabled') return String(rule.Enabled).toLowerCase() === 'false';
    return true;
  });

  const enabledCount  = rules.filter(r => String(r.Enabled).toLowerCase() === 'true').length;
  const disabledCount = rules.filter(r => String(r.Enabled).toLowerCase() === 'false').length;

  return (
    <div className="firewall-page">
      <div className="page-header">
        <div>
          <h1>Firewall Management</h1>
          <p className="subtitle">Firewall rules and security analysis</p>
        </div>
        <div className="header-buttons">
          <button className="btn-add" onClick={() => setShowAddModal(true)} disabled={!backendReady}>+ Add Rule</button>
          <button className="btn-scan" onClick={loadFirewallData} disabled={loading || !backendReady}>
            {loading && <Spinner size={13} color="#fff" />}
            {loading ? 'Loading…' : 'Refresh'}
          </button>
        </div>
      </div>

      {!backendReady && !firewallResults && (
        <div className="loading-state">Connecting to backend…</div>
      )}

      {error && (
        <div className="error-banner">
          <strong>Error:</strong> {error}
          <button className="btn-retry" onClick={loadFirewallData} disabled={loading}>Retry</button>
        </div>
      )}

      <div className="stats-container">
        <div className="stat-box"><div className="stat-label">Total Rules</div><div className="stat-value">{rules.length}</div><div className="stat-meta">configured</div></div>
        <div className="stat-box"><div className="stat-label">Enabled</div><div className="stat-value">{enabledCount}</div><div className="stat-meta">active rules</div></div>
        <div className="stat-box"><div className="stat-label">Disabled</div><div className="stat-value">{disabledCount}</div><div className="stat-meta">inactive rules</div></div>
        <div className="stat-box"><div className="stat-label">Issues Found</div><div className="stat-value">{issues.length}</div><div className="stat-meta">need attention</div></div>
      </div>

      {issues.length > 0 && (
        <div className="section alert-section">
          <div className="section-header"><h2>Detected Issues</h2><span className="count">{issues.length}</span></div>
          <div className="issues-grid">
            {issues.map((issue, idx) => (
              <div key={idx} className={`issue-card severity-${issue.severity.toLowerCase()}`}>
                <div className="issue-header">
                  <span className={`severity-badge ${issue.severity.toLowerCase()}`}>{issue.severity}</span>
                  <span className="issue-type">{issue.issue_type}</span>
                </div>
                <div className="issue-rule">{issue.rule_name}</div>
                <div className="issue-fix">{issue.suggested_fix}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="section">
        <div className="filter-bar">
          <div className="filter-group">
            {[['all', `All (${rules.length})`], ['issues', `With Issues (${issues.length})`], ['enabled', `Enabled (${enabledCount})`], ['disabled', `Disabled (${disabledCount})`]].map(([key, label]) => (
              <button key={key} className={filter === key ? 'filter-btn active' : 'filter-btn'} onClick={() => setFilter(key)}>{label}</button>
            ))}
          </div>
        </div>

        <table className="data-table firewall-table">
          <thead>
            <tr><th>Rule Name</th><th>Direction</th><th>Action</th><th>Profile</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {filteredRules.map((rule, idx) => {
              const hasIssue = issues.some(i => i.rule_name === rule.DisplayName);
              const isEnabled = String(rule.Enabled).toLowerCase() === 'true';
              return (
                <tr key={idx} className={hasIssue ? 'issue-row' : ''}>
                  <td className="rule-name">{rule.DisplayName}{hasIssue && <span className="issue-indicator">!</span>}</td>
                  <td>{rule.Direction || '—'}</td>
                  <td><span className={`action-badge ${String(rule.Action ?? '').toLowerCase()}`}>{rule.Action || '—'}</span></td>
                  <td>{rule.Profile || '—'}</td>
                  <td><span className={isEnabled ? 'status-enabled' : 'status-disabled'}>{isEnabled ? 'Enabled' : 'Disabled'}</span></td>
                  <td className="action-buttons">
                    {isEnabled
                      ? <button className="btn-action btn-disable" onClick={() => handleToggleRule(rule.DisplayName, false)}>Disable</button>
                      : <button className="btn-action btn-enable"  onClick={() => handleToggleRule(rule.DisplayName, true)}>Enable</button>
                    }
                    <button className="btn-action btn-remove" onClick={() => handleRemoveRule(rule.DisplayName)}>Remove</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {filteredRules.length === 0 && !loading && backendReady && (
          <div className="empty-state"><h3>No rules found</h3><p>No firewall rules match the current filter</p></div>
        )}
      </div>

      {showAddModal && (
        <div className="modal-overlay" onClick={() => setShowAddModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Add Firewall Rule</h2>
              <button className="modal-close" onClick={() => setShowAddModal(false)}>×</button>
            </div>
            <form onSubmit={handleAddRule}>
              <div className="form-grid">
                <div className="form-group">
                  <label>Rule Name *</label>
                  <input type="text" value={newRule.name} onChange={e => setNewRule({...newRule, name: e.target.value})} placeholder="e.g., Block Port 8080" required />
                </div>
                <div className="form-group">
                  <label>Port Number *</label>
                  <input type="text" value={newRule.port} onChange={e => setNewRule({...newRule, port: e.target.value})} placeholder="e.g., 8080 or Any" required />
                </div>
                <div className="form-group">
                  <label>Protocol</label>
                  <select value={newRule.protocol} onChange={e => setNewRule({...newRule, protocol: e.target.value})}>
                    <option value="tcp">TCP</option><option value="udp">UDP</option><option value="icmp">ICMP</option><option value="any">Any</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Action</label>
                  <select value={newRule.action} onChange={e => setNewRule({...newRule, action: e.target.value})}>
                    <option value="Block">Block</option><option value="Allow">Allow</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Direction</label>
                  <select value={newRule.direction} onChange={e => setNewRule({...newRule, direction: e.target.value})}>
                    <option value="Inbound">Inbound</option><option value="Outbound">Outbound</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Source IP (optional)</label>
                  <input type="text" value={newRule.source_ip} onChange={e => setNewRule({...newRule, source_ip: e.target.value})} placeholder="e.g., 192.168.1.100" />
                </div>
                <div className="form-group full-width">
                  <label>Description (optional)</label>
                  <input type="text" value={newRule.description} onChange={e => setNewRule({...newRule, description: e.target.value})} placeholder="Brief description of this rule" />
                </div>
              </div>
              <div className="modal-actions">
                <button type="button" className="btn-cancel" onClick={() => setShowAddModal(false)}>Cancel</button>
                <button type="submit" className="btn-submit">Create Rule</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Firewall;
