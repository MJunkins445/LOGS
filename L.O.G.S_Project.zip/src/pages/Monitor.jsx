import { useState, useEffect, useRef } from 'react';
import { apiFetch } from '../useBackend';
import { Spinner } from '../components/LoadingBar';
import './Monitor.css';

const SEVERITY_CLASS = {
  Strong: 'severity-strong',
  Moderate: 'severity-moderate',
  Mild: 'severity-mild',
};

// Poll interval in ms for each status
const POLL_INTERVAL = {
  connecting: 1500,
  collecting_baseline: 3000,
  starting: 2000,
  stopping: 2000,
  running: 10000,
  default: null,
};

export default function Monitor() {
  const [state, setState] = useState(null); // null = loading
  const [actionLoading, setActionLoading] = useState(false);
  const pollRef = useRef(null);

  async function fetchStatus() {
    try {
      const data = await apiFetch('/api/monitor/status');
      setState(data);
    } catch {
      // backend not ready yet — keep polling
    }
  }

  // Initial fetch
  useEffect(() => {
    fetchStatus();
  }, []);

  // Set up polling based on current status
  useEffect(() => {
    clearInterval(pollRef.current);
    const interval = state
      ? (POLL_INTERVAL[state.status] ?? POLL_INTERVAL.default)
      : POLL_INTERVAL.connecting;
    if (interval) {
      pollRef.current = setInterval(fetchStatus, interval);
    }
    return () => clearInterval(pollRef.current);
  }, [state?.status]);

  async function post(url) {
    return apiFetch(url, { method: 'POST' });
  }

  async function handleStartBaseline() {
    setActionLoading(true);
    try {
      const data = await post('/api/monitor/baseline/start');
      if (data.success) await fetchStatus();
      else setState(s => ({ ...s, error: data.message }));
    } finally {
      setActionLoading(false);
    }
  }

  async function handleResetBaseline() {
    if (!confirm('This will delete your current baseline and model. You will need to re-run the setup scan. Continue?')) return;
    setActionLoading(true);
    try {
      await post('/api/monitor/baseline/reset');
      await fetchStatus();
    } finally {
      setActionLoading(false);
    }
  }

  async function handleStartMonitor() {
    setActionLoading(true);
    try {
      const data = await post('/api/monitor/start');
      if (data.success) await fetchStatus();
      else setState(s => ({ ...s, error: data.message }));
    } finally {
      setActionLoading(false);
    }
  }

  async function handleStop() {
    setActionLoading(true);
    try {
      await post('/api/monitor/stop');
      await fetchStatus();
    } finally {
      setActionLoading(false);
    }
  }

  async function handleClearAlerts() {
    await post('/api/monitor/alerts/clear');
    setState(s => ({ ...s, alerts: [] }));
  }

  // ── Loading ──────────────────────────────────────────────────────────────
  if (!state) {
    return (
      <div className="monitor-page">
        <div className="loading-state">Connecting to backend…</div>
      </div>
    );
  }

  const { status, alerts = [], windows_analyzed, baseline_progress, error } = state;
  const progress = baseline_progress ?? { current: 0, total: 10 };
  const pct = progress.total > 0 ? Math.round((progress.current / progress.total) * 100) : 0;
  const secRemaining = (progress.total - progress.current) * 15;

  // ── Setup required ────────────────────────────────────────────────────────
  if (status === 'needs_baseline') {
    return (
      <div className="monitor-page">
        <div className="setup-card">
          <div className="setup-icon">🛡</div>
          <h2>Setup Required</h2>
          <p className="setup-desc">
            Before monitoring can begin, L.O.G.S. needs to learn what
            <em> normal </em> traffic looks like on <em>your</em> network.
          </p>
          <div className="setup-details">
            <div className="setup-detail-row">
              <span className="detail-icon">⏱</span>
              <span>Takes about <strong>{Math.ceil((progress.total * 15) / 60)} minutes</strong> — leave your computer running normally</span>
            </div>
            <div className="setup-detail-row">
              <span className="detail-icon">📡</span>
              <span>Captures <strong>{progress.total} traffic windows</strong> to build your personal baseline</span>
            </div>
            <div className="setup-detail-row">
              <span className="detail-icon">🔒</span>
              <span>All data stays <strong>local</strong> — nothing is sent to the cloud</span>
            </div>
          </div>
          {error && <div className="error-banner">{error}</div>}
          <button
            className="btn-setup"
            onClick={handleStartBaseline}
            disabled={actionLoading}
          >
            {actionLoading && <Spinner size={15} color="#fff" />}
            {actionLoading ? 'Starting…' : 'Start Setup Scan'}
          </button>
        </div>
      </div>
    );
  }

  // ── Collecting baseline ───────────────────────────────────────────────────
  if (status === 'collecting_baseline') {
    return (
      <div className="monitor-page">
        <div className="setup-card">
          <div className="setup-icon collecting-spin">📡</div>
          <h2>Learning Your Network…</h2>
          <p className="setup-desc">
            Please use your computer normally. L.O.G.S. is recording baseline traffic patterns.
          </p>

          <div className="progress-area">
            <div className="progress-numbers">
              <span>{progress.current} / {progress.total} windows</span>
              <span>{pct}%</span>
            </div>
            <div className="progress-bar-track">
              <div className="progress-bar-fill" style={{ width: `${pct}%` }} />
            </div>
            <div className="progress-eta">
              {progress.current < progress.total
                ? `~${Math.ceil(secRemaining / 60)} min ${secRemaining % 60} sec remaining`
                : 'Training model…'}
            </div>
          </div>

          <div className="collecting-tips">
            <p className="tips-title">While you wait:</p>
            <ul>
              <li>Browse the web, check email, use apps as usual</li>
              <li>Avoid running large downloads or backups during setup</li>
              <li>The more typical the traffic, the better the baseline</li>
            </ul>
          </div>
        </div>
      </div>
    );
  }

  // ── Normal monitor view (stopped / starting / running / stopping / error) ──
  const isRunning  = status === 'running' || status === 'starting';
  const isStopping = status === 'stopping';

  return (
    <div className="monitor-page">
      <div className="page-header">
        <div>
          <h1>Live Traffic Monitor</h1>
          <p className="subtitle">ML-based anomaly detection on live network traffic</p>
        </div>
        <div className="monitor-controls">
          {!isRunning && !isStopping ? (
            <button className="btn-start" onClick={handleStartMonitor} disabled={actionLoading || status === 'error'}>
              {actionLoading && <Spinner size={13} color="#fff" />}
              {actionLoading ? 'Starting…' : '▶ Start Monitor'}
            </button>
          ) : (
            <button className="btn-stop" onClick={handleStop} disabled={actionLoading || isStopping}>
              {isStopping
                ? '■ Stopping…'
                : actionLoading ? 'Stopping…' : '■ Stop Monitor'}
            </button>
          )}
          <button className="btn-reset" onClick={handleResetBaseline} disabled={actionLoading || isRunning || isStopping} title="Re-run setup scan">
            ↺ Reset Baseline
          </button>
        </div>
      </div>

      <div className="monitor-stats">
        <div className="stat-card">
          <div className="stat-label">Status</div>
          <div className={`status-badge status-${status}`}>
            {(isRunning || isStopping) && <span className="pulse-dot" />}
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Windows Analyzed</div>
          <div className="stat-number">{windows_analyzed}</div>
          <div className="stat-meta">× 15 sec each</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Alerts Detected</div>
          <div className={`stat-number ${alerts.length > 0 ? 'alert-count' : ''}`}>{alerts.length}</div>
          <div className="stat-meta">most recent 50</div>
        </div>
      </div>

      {error && (
        <div className="error-banner">
          <strong>Error:</strong> {error}
        </div>
      )}

      {isRunning && (
        <div className="info-banner">
          Capturing 15-second traffic windows and scoring against <em>your</em> baseline. Auto-refreshes every 10 s.
        </div>
      )}
      {isStopping && (
        <div className="info-banner">
          Finishing current capture window before stopping…
        </div>
      )}

      <div className="alerts-section">
        <div className="section-header">
          <h2>Anomaly Alerts</h2>
          {alerts.length > 0 && (
            <button className="btn-clear" onClick={handleClearAlerts}>Clear All</button>
          )}
        </div>

        {alerts.length === 0 ? (
          <div className="empty-state">
            {isRunning ? 'No anomalies detected yet. Monitoring…'
              : isStopping ? 'Stopping…'
              : 'Start the monitor to begin detecting anomalies.'}
          </div>
        ) : (
          <div className="alert-list">
            {alerts.map((alert, idx) => (
              <div key={idx} className={`alert-card ${SEVERITY_CLASS[alert.severity] || ''}`}>
                <div className="alert-header">
                  <span className={`severity-tag ${SEVERITY_CLASS[alert.severity] || ''}`}>
                    {alert.severity}
                  </span>
                  {alert.attack_type && (
                    <span className="attack-type-tag">{alert.attack_type}</span>
                  )}
                  <span className="alert-score">Score: {alert.score}</span>
                  <span className="alert-time">{alert.timestamp}</span>
                </div>

                {alert.top_reasons?.length > 0 && (
                  <div className="alert-reasons">
                    <div className="reasons-label">Top Indicators</div>
                    <div className="reasons-grid">
                      {alert.top_reasons.map((r, i) => (
                        <div key={i} className={`reason-chip impact-${r.impact?.toLowerCase()}`}>
                          <span className="reason-name">{r.name}</span>
                          <span className="reason-impact">{r.impact}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {alert.targeted_ports?.length > 0 && (
                  <div className="alert-ports">
                    <div className="ports-label">Targeted Ports</div>
                    <div className="ports-list">
                      {alert.targeted_ports.map((p, i) => (
                        <span key={i} className="port-chip">:{p.port}</span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
